	package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDao {
	
	public boolean studentLoginCheck(int uname, String pass) {
		String sql = "select * from login_d where uname=? and pass=?;";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, uname);
			st.setString(2, pass);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				return true;
			}
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return false;
	}
	
	
	public boolean facultyLoginCheck(int uname, String pass) {
		String sql = "select * from faculty_details where fid=? and pass=?;";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(2, pass);
			pt.setInt(1, uname);
			ResultSet rs = pt.executeQuery();
			if(rs.next()) {
				return true;
			}
			
		}
			catch(Exception e) {
				
			}
		return false;
			
			
		
		
	}
	
	public String getFacultyName(int uname) {
		String sql = "select name from faculty_details where fid=?";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, uname);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return "Error";
	}
	
	
	
	public String getStudentName(int uname) {
		String tname = "registration";
		String sql = "select name from "+tname+" where roll=?";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			PreparedStatement st = con.prepareStatement(sql);
			st.setInt(1, uname);
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return "Error";
	}
	

}





