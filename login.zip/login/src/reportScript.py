import xlsxwriter
import mysql.connector
import smtplib
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders 
import sys
   

def fetch_table_data(table_name):
    # The connect() constructor creates a connection to the MySQL server and returns a MySQLConnection object.
    cnx = mysql.connector.connect(
        host='localhost',
        database='sachin',
        user='root',
        password='8439',
        auth_plugin='mysql_native_password'
    )

    cursor = cnx.cursor()
    cursor.execute('select * from ' + table_name)

    header = [row[0] for row in cursor.description]

    rows = cursor.fetchall()

    # Closing connection
    cnx.close()

    return header, rows


def export(table_name):
    # Create an new Excel file and add a worksheet.
    workbook = xlsxwriter.Workbook(table_name+'.xlsx')
    worksheet = workbook.add_worksheet('Attendance')

    # Create style for cells
    header_cell_format = workbook.add_format({'bold': True, 'border': True, 'bg_color': 'yellow'})
    body_cell_format = workbook.add_format({'border': True})

    header, rows = fetch_table_data(table_name)

    row_index = 0
    column_index = 0

    for column_name in header:
        worksheet.write(row_index, column_index, column_name, header_cell_format)
        column_index += 1

    row_index += 1
    for row in rows:
        column_index = 0
        for column in row:
            worksheet.write(row_index, column_index, column, body_cell_format)
            column_index += 1
        row_index += 1

    print(str(row_index) + ' rows written successfully to ' + workbook.filename)

    # Closing workbook
    workbook.close()
    # email()
def email():


    fro = "email_from"

    to = "email_to"

    # instance of MIMEMultipart

    data = MIMEMultipart()

    # storing the senders email address  

    data['From'] = fro

    # storing the receivers email address 

    data['To'] = to

    # storing the subject 

    data['Subject'] = "Subject of the Mail"

    # string to store the body of the mail

    body = "Body-of-the-mail"

    # attach the body with the msg instance

    data.attach(MIMEText(body, 'plain'))

    # open the file to be sent 

    filename = "dummy.xlsx"

    attachment = open("dummy.xlsx", "rb")

    # instance of MIMEBase and named as p

    p = MIMEBase('application', 'octet-stream')

    # To change the payload into encoded form

    p.set_payload((attachment).read())

    # encode into base64

    encoders.encode_base64(p)

    p.add_header('Content-Disposition', "attachment; filename= %s" % filename)

    # attach the instance 'p' to instance 'msg'

    data.attach(p)

    # creates SMTP session

    s = smtplib.SMTP('smtp.gmail.com', 587)

    # start TLS for security

    s.starttls()

    # Authentication

    s.login(fro, "YourPasswordHere")

    # Converts the Multipart msg into a string

    text = data.as_string()

    # sending the mail

    s.sendmail(fro, to, text)

    # terminating the session

    s.quit()

# Tables to be exported
fid = sys.argv[1]

name = fid+"_attendance"

export(name)
