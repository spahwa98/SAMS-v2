

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Attendance.AttendanceDao;


@WebServlet("/CheckLock")
public class CheckLock extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int fid = Integer.parseInt(request.getParameter("fid"));
		
		AttendanceDao dao =  new AttendanceDao();
		int locked = dao.getLockedInfo(fid);
		
		if(locked == 1) {
			PrintWriter pw = response.getWriter();
			pw.println("<script type=\"text/javascript\"> ");
			pw.println("alert('Sorry !! You can not mark your attendance as teacher has already locked the attendance room.');");
			pw.println("location = 'student_login.jsp';");
			pw.println("</script>");
		}
		else if(locked == 1234){
			PrintWriter pw = response.getWriter();
			pw.println("<script type=\"text/javascript\"> ");
			pw.println("alert('Sorry !! An errot occured');");
			pw.println("location = 'student_login.jsp';");
			pw.println("</script>");
		}
		else if(locked == 1233){
			PrintWriter pw = response.getWriter();
			pw.println("<script type=\"text/javascript\"> ");
			pw.println("alert('Sorry !! There is no attendance room active with this faculty id.');");
			pw.println("location = 'student_login.jsp';");
			pw.println("</script>");
		}
		else if(locked == 0) {
			response.sendRedirect("markAttendance.jsp");
		}
	
	}


}
