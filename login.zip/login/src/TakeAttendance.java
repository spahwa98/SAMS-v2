

import java.io.IOException;
import java.time.LocalDate;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Attendance.AttendanceDao;

@WebServlet("/TakeAttendance")
public class TakeAttendance extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String lnum = request.getParameter("lnum");
		System.out.println(lnum+"lnum");
		Random ran = new Random();
		
		
		HttpSession	 session = request.getSession();	
		String fid = String.valueOf(session.getAttribute("uname"));
		
		int otp = 1000 + ran.nextInt(9000);
		int clnum = Integer.parseInt(lnum);
		
		request.setAttribute("lnum", clnum);
		request.setAttribute("otp", otp);
		
		session.setAttribute("lnum", clnum);

		AttendanceDao dao = new AttendanceDao();
		dao.entryLog(fid, clnum, otp);
		dao.createAttendanceTable(fid);
		
		RequestDispatcher rd = request.getRequestDispatcher("faculty_attendance.jsp");
		rd.forward(request, response);
		
	}

}
