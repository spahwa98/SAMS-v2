

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Attendance.AttendanceDao;

@WebServlet("/MarkAttendance")
public class MarkAttendance extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String uname = String.valueOf(session.getAttribute("uname"));
		int otp = Integer.parseInt(request.getParameter("otp"));
		int fid = Integer.parseInt(request.getParameter("fid"));
		String lnum = String.valueOf(request.getParameter("lnum"));
		String sfid = String.valueOf(fid);

		AttendanceDao dao =  new AttendanceDao();
		int locked = dao.getLockedInfo(fid);

		int cotp = dao.getOtp(fid);

		if(cotp == 1234){
			PrintWriter pw = response.getWriter();
			pw.println("<script type=\"text/javascript\"> ");
			pw.println("alert('Sorry !! An errot occured');");
			pw.println("location = 'student_login.jsp';");
			pw.println("</script>");
		}
		else if(cotp != otp){
			PrintWriter pw = response.getWriter();
			pw.println("<script type=\"text/javascript\"> ");
			pw.println("alert('Sorry !! You have entered wrong otp so your attendance can not be marked');");
			pw.println("location = 'student_login.jsp';");
			pw.println("</script>");
		}
		else {
			int flag = 0;
			if(dao.check(uname)==true) {
				dao.markAttendance(lnum, uname);
				boolean b3 = dao.markDummyAttendance(uname, sfid);
				flag=1;

			}
			else {
				boolean b1 = dao.createRow(uname);
				boolean b2 = dao.markAttendance(lnum, uname);
				boolean b3 = dao.markDummyAttendance(uname, sfid);
				flag=1;
			}
			if(flag==1) {
				PrintWriter pw = response.getWriter();
				pw.println("<script type=\"text/javascript\"> ");
				pw.println("alert('Attendance marked successfully');");
				pw.println("location = 'student_login.jsp';");
				pw.println("</script>");
			}
			else {
				PrintWriter pw = response.getWriter();
				pw.println("<script type=\"text/javascript\"> ");
				pw.println("alert('Sorry! An error occured so your attendance can't me marked');");
				pw.println("location = 'student_login.jsp';");
				pw.println("</script>");
			}

		}

	}
}




