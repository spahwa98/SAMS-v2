

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import register.RegisterDao;

@WebServlet("/FacultyRegister")
public class FacultyRegister extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String dept = request.getParameter("dept");
		int fid = Integer.parseInt(request.getParameter("fid"));
		String pass = request.getParameter("pass_1");
		
		RegisterDao dao = new RegisterDao();
		if(dao.checkFaculty(fid)) {
			
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			out.println("<script type=\"text/javascript\">");
			out.println("alert('You Are Already Registered With Us.. '); ");
			out.println("location='index.jsp';");
			out.println("</script>");
			
			
		}
		
		else {
			boolean b = new RegisterDao().insertFacultyLoginDetails(fid, name, dept, pass);
			
			if(b==true) {
				PrintWriter out = response.getWriter();
				
				response.setContentType("text/html");
				out.println("<script type=\"text/javascript\">");
				out.println("alert('You have Successfully Registered Yourself With Us..');");
				out.println("location='index.jsp';");
				out.println("</script>");
			}
			else {
				PrintWriter out = response.getWriter();
				
				out.println("<script type=\"text/javascript\">");
				out.println("alert('There is some problem registering. please try again later again.');");
				out.println("location='index.jsp';");
				out.println("</script>");
			}
		
		}
		
	}

}
