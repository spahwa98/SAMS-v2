package Attendance;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;

public class AttendanceDao {
	LocalDate date = LocalDate.now();
	String cdate = date.toString();
	
	
	public boolean check(String uname) {
		String tname = String.valueOf(uname)+"_attendance" ;
		String sql = "select * from "+tname+" where c_date = ?;";
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(1, cdate);
			ResultSet rs = pt.executeQuery();
			if(rs.next()) {
				return true;
			}
			else {
				return false;
			}
		}
		catch(Exception e) {
			return false;
		}
		
		
	}
	
	public boolean markAttendance(String lnum, String uname) {
		String tname = String.valueOf(uname)+"_attendance" ;
		String l = "lecture"+String.valueOf(lnum);
		String sql = "update "+tname+" set "+l+"=? where c_date=? ";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(1, "P");
			pt.setString(2, cdate);
			pt.executeUpdate();
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean markDummyAttendance(String uname, String fid) {
		String tname = fid+"_attendance" ;
		String sql = "INSERT INTO "+tname+" VALUES(?)";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(1, uname);
			pt.executeUpdate();
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public boolean createRow(String uname) {
		String tname = String.valueOf(uname)+"_attendance" ;
		String sql = "INSERT INTO "+tname+"(c_date) VALUES(?)";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(1, cdate);
			pt.executeUpdate();
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public boolean emptyTable() {
		String tname = "current_attendance" ;
		String sql = "TRUNCATE TABLE "+tname;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.executeUpdate();
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	
	
	public boolean entryLog(String fid, int clnum, int otp) {
		String tname = "current_attendance_details" ;
		
		String sql = "insert into "+tname+" values(?, ?, ?, ?)";
		int ifid = Integer.parseInt(fid);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setInt(1, ifid);
			pt.setInt(2, clnum);
			pt.setInt(3, otp);
			pt.setInt(4,  0);
			pt.executeUpdate();
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public boolean markLock(String fid) {
		String tname = "current_attendance_details" ;
		int ifid = Integer.parseInt(fid);
		String sql = "update "+tname+" set locked=? where fid=? ";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setInt(1, 1);
			pt.setInt(2, ifid);
			pt.executeUpdate();
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	public int getLockedInfo(int fid) {
		String tname = "current_attendance_details" ;
		String sql = "select locked from "+tname+" where fid=?";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setInt(1, fid);
			ResultSet rs = pt.executeQuery();
			
			while(rs.next()) {
				int locked = rs.getInt("locked");
				return locked;
			}
			return 1233;
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return 1234;
		}
	}
	
	
	public int getOtp(int fid) {
		String tname = "current_attendance_details" ;
		String sql = "select otp from "+tname+" where fid=?";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setInt(1, fid);
			ResultSet rs = pt.executeQuery();
			
			while(rs.next()) {
				int otp = rs.getInt("otp");
				return otp;
			}
			return 1233;
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return 1234;
		}
	}
	
	
	
	public boolean createAttendanceTable(String fid) {
		String tname = fid+"_attendance" ;
		String sql = "create table "+tname+" (roll_no int(10));";
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root" , "8439");
			
			Statement st = con.createStatement();		
			
			st.executeUpdate(sql);		
			
		}
		catch(Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		
		return true;
		
	}
	
	
	
	public boolean dropTableAndRow(String fid) {
		String tname = fid+"_attendance" ;
		String sql = "drop table "+tname;
		String sql1 = "delete from current_attendance_details where fid="+fid;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sachin", "root", "8439");
			
			Statement stmt = con.createStatement();
			stmt.execute(sql);
			stmt.executeUpdate(sql1);
			
			return true;
		}
		catch(Exception e) {
			return false;
		}
		
		
	}

}


