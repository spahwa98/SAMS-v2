



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import login.LoginDao;

@WebServlet("/Login")
public class Login extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int uname = Integer.parseInt(request.getParameter("username"));
		String pass = request.getParameter("password");
		String opt = request.getParameter("c_login");
		LoginDao dao = new LoginDao();
		
		if(opt.equals("faculty")) {
			if(dao.facultyLoginCheck(uname,pass)) {
				String name = dao.getFacultyName(uname);
				HttpSession session = request.getSession();	
				session.setAttribute("fname", name);
				session.setAttribute("uname", uname);
				response.sendRedirect("faculty_login.jsp");
			}
			else {
				PrintWriter pw = response.getWriter();
				pw.println("<script type=\"text/javascript\"> ");
				pw.println("alert('Login Details Not Found or Either You Have Entered Wrong Details');");
				pw.println("location = 'index.jsp';");
				pw.println("</script>");
			}
		}
		else {
			
			if(dao.studentLoginCheck(uname,pass)) {
				RequestDispatcher rd = request.getRequestDispatcher("student_login.jsp");
				String name = dao.getStudentName(uname);
				HttpSession session = request.getSession();	
				session.setAttribute("sname", name);
				session.setAttribute("uname", uname);			
				
				rd.forward(request, response);
			}
			else {
				PrintWriter pw = response.getWriter();
				pw.println("<script type=\"text/javascript\"> ");
				pw.println("alert('Login Details Not Found or Either You Have Entered Wrong Details');");
				pw.println("location = 'index.jsp';");
				pw.println("</script>");
			}
		}
		
	
	}

}
