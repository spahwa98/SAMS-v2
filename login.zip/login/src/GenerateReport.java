import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Attendance.AttendanceDao;

@WebServlet("/GenerateReport")
public class GenerateReport extends HttpServlet {
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			HttpSession session = request.getSession();	
			String fid = String.valueOf(session.getAttribute("uname"));
			String command = "python3 /home/sachin/Sachin/login/src/reportScript.py "+fid;
			Process p = Runtime.getRuntime().exec(command);
			
			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String ret = in.readLine();
			System.out.println("value is : "+ret);
			
			AttendanceDao dao = new AttendanceDao();
			dao.dropTableAndRow(fid);
			
			PrintWriter pw = response.getWriter();
			pw.println("<script type=\"text/javascript\"> ");
			pw.println("alert('Current lecture report has been sent to your registered e-mail id');");
			pw.println("location = 'faculty_login.jsp';");
			pw.println("</script>");
		}
}


