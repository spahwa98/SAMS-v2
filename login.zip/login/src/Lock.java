

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Attendance.AttendanceDao;

/**
 * Servlet implementation class Lock
 */
@WebServlet("/Lock")
public class Lock extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession	 session = request.getSession();
		String fid = String.valueOf(session.getAttribute("uname"));
		String otp = String.valueOf(request.getParameter("cotp"));
		
		System.out.println("otp"+ otp);
		
		AttendanceDao dao = new AttendanceDao();
		boolean b = dao.markLock(fid);
		
		if(b==false) {
			PrintWriter pw = response.getWriter();
			pw.println("<script type=\"text/javascript\"> ");
			pw.println("alert('Sorry !! An error occured while acquiring the lock');");
			pw.println("location = 'faculty_attendance.jsp';");
			pw.println("</script>");
		}
		else {
			

			request.setAttribute("otp", otp);
			request.setAttribute("locked", true);
			RequestDispatcher rd = request.getRequestDispatcher("faculty_attendance.jsp");
			rd.forward(request, response);
			
			
		}
	
	}

}
