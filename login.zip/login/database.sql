use test;


create database sachin;
use sachin;
create table login_d(uname varchar(100) , pass varchar(50));
insert into login_d values("sachin", 81);
insert into login_d values("sagar", 83);

select * from login_d;


